package com.genie.touch

import android.app.Service
import android.content.Intent
import android.content.res.Resources
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import android.media.MediaPlayer

class FloatingTouchService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var touchView: View
    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { fadeAndDock() }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        layoutParams.gravity = Gravity.TOP or Gravity.START
        layoutParams.x = 300
        layoutParams.y = 500

        touchView = LayoutInflater.from(this).inflate(R.layout.view_floating_genie, null)
        val genieButton = touchView.findViewById<ImageView>(R.id.genie_button)
        val arcMenu = touchView.findViewById<LinearLayout>(R.id.arc_menu)

        val fadeIn = android.view.animation.AlphaAnimation(0f, 1f)
        fadeIn.duration = 600
        touchView.startAnimation(fadeIn)

        val mediaPlayer = MediaPlayer.create(this, R.raw.genie_appear)
        mediaPlayer.start()

        var dX = 0f
        var dY = 0f

        touchView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = layoutParams.x - event.rawX
                    dY = layoutParams.y - event.rawY
                    touchView.alpha = 1f
                    hideHandler.removeCallbacks(hideRunnable)
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams.x = (event.rawX + dX).toInt()
                    layoutParams.y = (event.rawY + dY).toInt()
                    windowManager.updateViewLayout(touchView, layoutParams)
                }
                MotionEvent.ACTION_UP -> hideHandler.postDelayed(hideRunnable, 3000)
            }
            false
        }

        genieButton.setOnClickListener {
            arcMenu.visibility = if (arcMenu.visibility == View.GONE) View.VISIBLE else View.GONE
            hideHandler.removeCallbacks(hideRunnable)
            hideHandler.postDelayed(hideRunnable, 3000)
        }

        arcMenu.findViewById<ImageView>(R.id.btn_home).setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
        }
        arcMenu.findViewById<ImageView>(R.id.btn_lock).setOnClickListener {
            Toast.makeText(this, "Lock", Toast.LENGTH_SHORT).show()
        }
        arcMenu.findViewById<ImageView>(R.id.btn_recent).setOnClickListener {
            Toast.makeText(this, "Recent", Toast.LENGTH_SHORT).show()
        }
        arcMenu.findViewById<ImageView>(R.id.btn_screenshot).setOnClickListener {
            Toast.makeText(this, "Screenshot", Toast.LENGTH_SHORT).show()
        }

        windowManager.addView(touchView, layoutParams)
        hideHandler.postDelayed(hideRunnable, 3000)
    }

    private fun fadeAndDock() {
        touchView.animate().alpha(0.4f).setDuration(500).start()
        val layoutParams = touchView.layoutParams as WindowManager.LayoutParams
        val screenWidth = Resources.getSystem().displayMetrics.widthPixels
        layoutParams.x = if (layoutParams.x + touchView.width / 2 < screenWidth / 2) 0 else screenWidth - touchView.width
        windowManager.updateViewLayout(touchView, layoutParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.removeView(touchView)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}